from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(client)
admin.site.register(chambre)
admin.site.register(type_chambre)
admin.site.register(location)
