from django.contrib import admin

from number.models import User

# Register your models here.
admin.site.register(User)